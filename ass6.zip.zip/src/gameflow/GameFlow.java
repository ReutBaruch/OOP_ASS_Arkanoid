package gameflow;

import animation.AnimationRunner;
import animation.KeyPressStoppableAnimation;
import animation.EndScreenLose;
import animation.EndScreenWin;
import animation.HighScoresAnimation;
import animation.Task;
import animation.Menu;
import animation.MenuAnimation;
import biuoop.DialogManager;
import indicator.Counter;
import gameobjects.LevelInformation;
import biuoop.GUI;
import biuoop.KeyboardSensor;
import levels.LevelSets;
import levels.LevelsSet;
import io.LevelSpecificationReader;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * in charge of creating the differnet levels, and moving from one level to the next.
 */
public class GameFlow {
    private KeyboardSensor keyboardSensor;
    private AnimationRunner animationRunner;
    private GUI gui;
    private Counter livesCounter;
    private Counter score;
    private HighScoresTable table;
    private DialogManager dialog;
    private List<LevelInformation> levels;

    /**
     * constructor.
     * @param levels returns the game's levels
     */
    public GameFlow(List<LevelInformation> levels) {
        this.gui = new GUI("Arkanoid", 800, 600); //creates new screen
        dialog = gui.getDialogManager();
        this.keyboardSensor = gui.getKeyboardSensor();
        this.animationRunner = new AnimationRunner(3, gui);
        this.livesCounter = new Counter();
        this.score = new Counter();
        livesCounter.increase(7);
        table = new HighScoresTable(4);
        this.levels = levels;
    }

    /**
     * runs a set of level.
     * @param levelsSet a set of levels to run
     */
    public void runLevels(List<LevelInformation> levelsSet) {
        File highscores = new File("highscores");
        this.livesCounter.setCount(7);
        this.score.setCount(0);
        if (highscores.exists()) {
            try {
                table.load(highscores); //saves changes
            } catch (IOException e) {
                System.out.println(e);
            }
        } else { //creates a score table
            try {
                table.save(highscores);
            } catch (IOException e) {
                System.out.println(e);
            }
        }
        for (LevelInformation  levelInfo: levelsSet) {
            GameLevel level = new GameLevel(levelInfo, animationRunner, score, livesCounter, keyboardSensor,
                    gui);
            level.initialize();
            //level has more blocks and player has more lives
            while ((livesCounter.getValue() != 0) && (level.getBlockCounter().getValue() != 0)) {
                level.playOneTurn();
            }

            if (livesCounter.getValue() == 0) { //lose
                this.animationRunner.run(new KeyPressStoppableAnimation(this.keyboardSensor, "space",
                        new EndScreenLose(this.keyboardSensor, this.score)));
                break;
            }
        }
        if (livesCounter.getValue() != 0) { //win
            this.animationRunner.run(new KeyPressStoppableAnimation(this.keyboardSensor, "space",
                    new EndScreenWin(this.keyboardSensor, this.score)));
        }
        if (table.getRank(this.score.getValue()) <= table.size()) { //high score is saved
        String name = dialog.showQuestionDialog("Name", "What is your name?", "");
            ScoreInfo scoreInfo = new ScoreInfo(name, this.score.getValue());
            table.add(scoreInfo);
            try {
                table.save(highscores);
            } catch (IOException e) {
                System.out.println(e);
            }
        }
        //shows the score table
        this.animationRunner.run(new KeyPressStoppableAnimation(this.keyboardSensor, "space",
                new HighScoresAnimation(table)));
    }

    /**
     * shows the menu to the screen and operate accordingly.
     * @param levelsSet a set of levels
     */
    public void gameMenu(LevelSets levelsSet) {
        File highscores = new File("highscores");
        if (highscores.exists()) {
            try {
                table.load(highscores);
            } catch (IOException e) {
                System.out.println(e);
            }
        } else {
            try {
                table.save(highscores);
            } catch (IOException e) {
                System.out.println(e);
            }
        }
        Menu<Task<Void>> menu = new MenuAnimation<Task<Void>>(this.keyboardSensor, this.animationRunner);
        Menu<Task<Void>> subMenu = new MenuAnimation<Task<Void>>(this.keyboardSensor, this.animationRunner);
        for (LevelsSet levelSet : levelsSet.getLevelSetList()) { //for each level saves its properties
            subMenu.addSelection(levelSet.getKey(), "(" + levelSet.getKey() + ") " + levelSet.getMessage(),
                    new Task<Void>() {
                        @Override
                        public Void run() { //what to do in case irs chosen
                            List<LevelInformation> subLevels = new ArrayList<>();
                            try {
                                InputStream is = ClassLoader.getSystemClassLoader().getResourceAsStream("resources/"
                                + levelSet.getLevelDefinitionPath());
                                subLevels = new LevelSpecificationReader().fromReader(new InputStreamReader(is));
                                runLevels(subLevels);
                            } catch (Exception e) {
                                System.out.println(e); //something went wrong
                            }
                            return null;
                        }
                    });
        } //adds the main menu options
        menu.addSubMenu("s", "(s) Start game", subMenu);
        menu.addSelection("h", "(h) High scores", new Task<Void>() {
            @Override
            public Void run() {
                animationRunner.run(new KeyPressStoppableAnimation(keyboardSensor, "space",
                        new HighScoresAnimation(table)));
                return null;
            }
        });
        menu.addSelection("e", "(e) Exit", new Task<Void>() {
            @Override
            public Void run() {
                gui.close();
                return null;
            }
        });
        while (true) { //shows the mwnu
            animationRunner.run(menu);
            Task<Void> runTask = (Task) menu.getStatus();
            runTask.run();
            menu.setStop(false);
        }
        }
    }