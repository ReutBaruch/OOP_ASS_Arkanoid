package gameflow;

import animation.KeyPressStoppableAnimation;
import gameobjects.Rectangle;
import gameobjects.Block;
import gameobjects.Velocity;
import gameobjects.Point;
import gameobjects.Ball;
import gameobjects.Sprite;
import gameobjects.Collidable;
import gameobjects.GameEnvironment;
import gameobjects.LevelInformation;
import gameobjects.Paddle;
import gameobjects.SpriteCollection;
import indicator.Counter;
import indicator.LevelIndicator;
import indicator.LivesIndicator;
import indicator.ScoreIndicator;
import animation.Animation;
import listener.BallRemover;
import listener.BlockRemover;
import listener.ScoreTrackingListener;
import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.KeyboardSensor;
import biuoop.Sleeper;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * the class creates a new gameflow.
 * draws everything to the screen and starts the gameflow.
 */
public class GameLevel implements Animation {
    private SpriteCollection sprites;
    private GameEnvironment environment;
    private LevelInformation levelInformation;
    private Counter blockCounter;
    private Counter ballCounter;
    private Counter scoreCounter;
    private Counter livesCounter;
    private Paddle paddle;
    private animation.AnimationRunner runner;
    private boolean running;
    private GUI gui;
    private Sleeper sleeper;
    private biuoop.KeyboardSensor keyboard;
    private static final int PADDLE_HEIGHT = 20;
    private static final int WIDTH_BORDER = 20;
    private static final int FRAME_WIDTH = 800;
    private static final int HEIGHT_BORDER = 580;
    private static final int INFO_LINE = 30;
    private static final int SCREEN_MIDDLE = 380;
    private static final int POINT_REMOVE = 10;

    /**
     * constructor.
     * @param level all the level information.
     * @param ar an animation runner.
     * @param score counter that keep the score.
     * @param livesCounter counter that counts lives.
     * @param ks KeyboardSensor.
     * @param gui gui.
     */
    public GameLevel(LevelInformation level, animation.AnimationRunner ar, Counter score, Counter livesCounter,
                     KeyboardSensor ks, biuoop.GUI gui) {
        this.environment = new GameEnvironment();
        this.sprites = new SpriteCollection();
        this.blockCounter = new Counter();
        this.ballCounter = new Counter();
        this.scoreCounter = score;
        this.livesCounter = livesCounter;
        this.levelInformation = level;
        this.runner = ar;
        this.keyboard = ks;
        this.gui = gui;
    }

    /**
     * sets the sprites.
     */
    public void setSprites() {
        this.sprites = new SpriteCollection();
    }

    /**
     * sets the gameflow environment.
     */
    public void setEnvironment() {
        this.environment = new GameEnvironment();
    }

    /**
     * getter.
     * @return the number of remaining blocks.
     */
    public Counter getBlockCounter() {
        return this.blockCounter;
    }

    /**
     * adds a collidable to the gameflow environment.
     * @param c a collidable
     */
    public void addCollidable(Collidable c) {
        environment.addCollidable(c);
    }

    /**
     * adds a sprite to the sprites.
     * @param s a sprite.
     */
    public void addSprite(Sprite s) {
        sprites.addSprite(s);
    }

    /**
     * creates the ball.
     * @param x the X coordinate for the center
     * @param y the Y coordinate for the center
     * @param color the color of the ball
     * @param radius the radius of the ball
     * @param velocity the ball's velocity
     */
    public void createBall(int x, int y, Color color, int radius, Velocity velocity) {
        //the balls boundaries.
        Point width = new Point(0, 20);
        Point height = new Point(800, 600);
        Ball ball = new Ball(x, y, radius, color, width, height, velocity); //creates new ball
        ball.setGame(this.environment);
        ball.addToGame(this);
        ballCounter.increase(1);
    }

    /**
     * creates the paddle.
     * @param width the width
     * @param speed the speed
     * @param pointForPaddle the begging point
     */
    public void createPaddle(int width, int speed, Point pointForPaddle) {
        keyboard = gui.getKeyboardSensor();
        Rectangle rectForPaddle = new Rectangle(pointForPaddle, width, PADDLE_HEIGHT);
        Block forPaddle = new Block(rectForPaddle, Color.YELLOW);
        paddle = new Paddle(forPaddle, speed,  keyboard);
        paddle.addToGame(this);
    }

    /**
     * creates an info block.
     */
    public void createInfoBlock() {
        Point p = new Point(0, 0);
        Rectangle rectangle = new Rectangle(p, FRAME_WIDTH, 30);
        Block b = new Block(rectangle, Color.lightGray);
        b.addToGame(this);
        b.setHits(0);
    }

    /**
     * creates the rectangles for the frame.
     */
    public void createFrame() {
        List<Rectangle> rects = new ArrayList<>();
        List<Block> blocks = new ArrayList<>();
        Point pr1 = new Point(0, 30);
        Point pr3 = new Point(FRAME_WIDTH - 20, INFO_LINE + 20);
        rects.add(new Rectangle(pr1, WIDTH_BORDER, HEIGHT_BORDER + WIDTH_BORDER));
        rects.add(new Rectangle(pr1, FRAME_WIDTH, WIDTH_BORDER));
        rects.add(new Rectangle(pr3, 20, HEIGHT_BORDER));
        for (int i = 0; i < rects.size(); i++) {
            blocks.add(new Block(rects.get(i), Color.gray));
            blocks.get(i).addToGame(this);
            blocks.get(i).setHits(0);
        }
    }

    /**
     * creates the block that if the ball hits it, the ball is removed from game.
     * @param remover a listener
     */
    public void createDeathBlock(BallRemover remover) {
        Point pr2 = new Point(0, 600);
        Rectangle rect = new Rectangle(pr2, FRAME_WIDTH, WIDTH_BORDER);
        Block block = new Block(rect, Color.red);
        block.setHits(1);
        block.addHitListener(remover);
        block.addToGame(this);
    }

    /**
     * creates removable blocks on the screen.
     * @param blocks a list of blocks that needs to be created.
     */
    public void createBlock(List<Block> blocks) {
        BlockRemover blockRemover = new BlockRemover(this, blockCounter);
        ScoreTrackingListener score = new ScoreTrackingListener(this.scoreCounter);
        for (int i = 0; i < blocks.size(); i++) { //as long as there are more blocks to create
            //blocks.get(i).setHits(1);
            blocks.get(i).addHitListener(blockRemover);
            blocks.get(i).addHitListener(score);
            blocks.get(i).addToGame(this);
            blockCounter.increase(1);
        }
    }

    /**
     * the function chooses color for the block.
     * @param j the number of the block's line
     * @return the color of the block
     */
    public Color chooseColorForBlock(int j) {
     switch (j) {
         case (0):
             return Color.green;
         case (1):
             return Color.MAGENTA;
         case (2):
             return Color.orange;
         case (3):
             return Color.pink;
         case (4):
             return Color.darkGray;
             default:
                 return Color.BLACK;
     }
    }

    /**
     * removes a collidable from the game.
     * @param c a collidable
     */
    public void removeCollidable(Collidable c) {
        environment.removeCollidable(c);
        scoreCounter.increase(POINT_REMOVE); //when a block is removed - points
    }

    /**
     * remove sprite from game.
     * @param s a sprite
     */
    public void removeSprite(Sprite s) {
        sprites.removeSprite(s);
    }

    /**
     * Initialize a new gameflow: create the Blocks and gameobjects.Ball (and gameobjects.Paddle)
     * and add them to the gameflow.
     */
    public void initialize() {
        sleeper = new Sleeper();
        sprites.addSprite(levelInformation.getBackground());
        this.runner = new animation.AnimationRunner(60, gui);
        //this.livesCounter.increase(7);
        //this.scoreCounter.decrease(this.scoreCounter.getValue());
        BallRemover ballRemover = new BallRemover(this, ballCounter);
        ScoreIndicator scoreIndicator = new ScoreIndicator(scoreCounter);
        LivesIndicator livesIndicator = new LivesIndicator(livesCounter);
        LevelIndicator levelIndicator = new LevelIndicator(levelInformation.levelName());
        createPaddle(levelInformation.paddleWidth(), levelInformation.paddleSpeed(), levelInformation.paddlePoint());
        createInfoBlock();
        createBlock(levelInformation.blocks());
        createFrame();
        createDeathBlock(ballRemover);
        scoreIndicator.addToGame(this);
        livesIndicator.addToGame(this);
        levelIndicator.addToGame(this);
    }

    /**
     * plays one turn in the game.
     */
    public void playOneTurn() {
        this.createBallsOnTopOfPaddle(); // or a similar method
        this.runner.run(new animation.CountdownAnimation(2, 3, sprites)); // countdown before turn starts.
        this.running = true;
        // use our runner to run the current animation -- which is one turn of
        // the gameflow.
        this.runner.run(this);
    }

    /**
     * creates the balls on the paddle.
     * in every turn (when a level is changed or when all balls fall.
     */
    public void createBallsOnTopOfPaddle() {
        for (int i = 0; i < levelInformation.initialBallVelocities().size(); i++) {
            createBall(SCREEN_MIDDLE, 550, Color.BLACK, 8,
                    levelInformation.initialBallVelocities().get(i));
        }
        paddle.setPaddlePoint(levelInformation.paddlePoint().getX(), levelInformation.paddlePoint().getY());
    }

    /**
     * as long as there are more blocks to destroy.
     * and there are more lives.
     * runs the game.
     */
    public void run() {
        while (livesCounter.getValue() != 0) { //still have lives
            if (this.blockCounter.getValue() == 0) {
                gui.close();
                return;
            }
            playOneTurn(); //plays
        }
        gui.close();
    }

    /**
     * runs each frame of the game and takes care of the game logic.
     * @param d a draw surface.
     * @param dt the change in the velocity
     */
    @Override
    public void doOneFrame(DrawSurface d, double dt) {
        this.sprites.drawAllOn(d);
        this.sprites.notifyAllTimePassed(dt);
        if (this.keyboard.isPressed("p")) { //in order to pause the game
            this.runner.run(new KeyPressStoppableAnimation(this.keyboard, "space",
                    new animation.PauseScreen(this.keyboard)));
        }
        if (blockCounter.getValue() == 0) { //if the level was finished
            scoreCounter.increase(100);
            this.running = false;
        }
        if (ballCounter.getValue() == 0) { //lost all the balls
            livesCounter.decrease(1);
            this.running = false;
        }
        if (livesCounter.getValue() == 0) { //lost all the lives
            this.running = false;
        }
    }

    /**
     * stop condition.
     * @return true or false
     */
    @Override
    public boolean shouldStop() {
        return !this.running;
    }
}
