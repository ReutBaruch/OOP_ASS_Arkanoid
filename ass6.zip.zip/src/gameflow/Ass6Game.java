package gameflow;

import gameobjects.LevelInformation;
import levels.LevelSets;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.io.InputStream;
import java.io.LineNumberReader;
import java.util.ArrayList;
import java.util.List;

/**
 * runs the program.
 */
public class Ass6Game {
    /**
     * runs the game.
     * @param args can receive a path for a level set file.
     * @throws Exception can throw exceptions
     */
    public static void main(String[] args) throws Exception {
        List<LevelInformation> levels = new ArrayList<LevelInformation>();
        GameFlow game = new GameFlow(levels);
        String s = "";
        if (args.length == 0) { //if no path was received starts the default level set
            InputStream is = ClassLoader.getSystemClassLoader().getResourceAsStream("resources/level_sets.txt");
            LevelSets levelSets = new LevelSets();
            LineNumberReader lineReader = null;
            levelSets = levelSets.fromReader(new InputStreamReader(is));
            game.gameMenu(levelSets); //starts the game with the levels
        }
        String fileName = args[0];
        try { //receives a set of levels and runs it
            InputStream is = ClassLoader.getSystemClassLoader().getResourceAsStream("resources/" + fileName);
            LevelSets levelSets = new LevelSets();
            LineNumberReader lineReader = null;
            levelSets = levelSets.fromReader(new InputStreamReader(is));
            game.gameMenu(levelSets); //starts the game with the levels
        } catch (FileNotFoundException e) {
            System.out.println(e); //something went wrong
        }
    }
}
