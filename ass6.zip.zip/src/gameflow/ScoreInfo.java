package gameflow;

import java.io.Serializable;

/**
 * a class responsible for creating scores and the user name.
 */
public class ScoreInfo implements Serializable {
    private String name;
    private int score;

    /**
     * constructor.
     * @param name a user name
     * @param score a score
     */
    public ScoreInfo(String name, int score) {
        this.name = name;
        this.score = score;
    }

    /**
     * getter.
     * @return the user name
     */
    public String getName() {
        return this.name;
    }

    /**
     * getter.
     * @return the user score
     */
    public int getScore() {
        return this.score;
    }
}
