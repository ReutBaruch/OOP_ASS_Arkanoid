package listener;

import gameobjects.Ball;
import gameobjects.Block;
import indicator.Counter;
import gameobjects.HitListener;

/**
 * keep track of the score.
 */
public class ScoreTrackingListener implements HitListener {
    private Counter currentScore;

    /**
     * constructor.
     * @param scoreCounter a score counter
     */
    public ScoreTrackingListener(Counter scoreCounter) {
        this.currentScore = scoreCounter;
    }
    /**
     * This method is called whenever the beingHit object is hit.
     * The hitter parameter is the gameobjects.Ball that's doing the hitting.
     * when a hit occur the score rise with 5 points.
     * @param beingHit a block
     * @param hitter the ball
     */
    public void hitEvent(Block beingHit, Ball hitter) {
       this.currentScore.increase(5);
    }
}