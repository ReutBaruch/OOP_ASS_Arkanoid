package levels;

import animation.Background;
import animation.Drawable;
import gameobjects.Point;
import gameobjects.Rectangle;
import gameobjects.Block;
import gameobjects.LevelInformation;
import gameobjects.Velocity;
import gameobjects.Circle;
import gameobjects.Line;
import gameobjects.Sprite;


import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * level four class.
 * implements LevelInformation.
 */
public class LevelFour implements LevelInformation {
    private Velocity ballVelocity = new Velocity(0, -200);
    private static final int BALLS_NUM = 3;
    private static final int REMOVE_BLOCKS_NUM = 75;
    private static final int SCREEN_MIDDLE = 380;
    private static final int PADDLE_SPEED = 300;
    private static final int PADDLE_WIDTH = 150;
    private static final int HEIGHT_BORDER = 580;

    /**
     * the number of balls in the level.
     * @return number of balls
     */
    @Override
    public int numberOfBalls() {
        return BALLS_NUM;
    }

    /**
     * a list of the balls velocity.
     * @return a list with the velocities
     */
    @Override
    public List<Velocity> initialBallVelocities() {
        List<Velocity> listVelocity = new ArrayList<Velocity>();
        ballVelocity = new Velocity(200, -200);
        listVelocity.add(ballVelocity);
        ballVelocity = new Velocity(0, -200);
        listVelocity.add(ballVelocity);
        ballVelocity = new Velocity(-200, -200);
        listVelocity.add(ballVelocity);
        return listVelocity;
    }

    /**
     * paddle speed.
     * @return paddle speed.
     */
    @Override
    public int paddleSpeed() {
        return PADDLE_SPEED;
    }

    /**
     * the paddle width.
     * @return the paddle width.
     */
    @Override
    public int paddleWidth() {
        return PADDLE_WIDTH;
    }
    /**
     * the location of the paddle.
     * @return a point
     */
    @Override
    public Point paddlePoint() {
        Point pointForPaddle = new Point(SCREEN_MIDDLE - (PADDLE_WIDTH / 2), HEIGHT_BORDER - 20);
        return pointForPaddle;
    }

    /**
     * the level name.
     * @return a name
     */
    @Override
    public String levelName() {
        return "Final Four";
    }

    /**
     * help function to draw the background.
     * the function draws a cloud.
     * @param x the x coordinate.
     * @param y the y coordinate
     * @return a list of drawables shapes
     */
    public List drawCloud(int x, int y) {
        List<Drawable> drawables = new ArrayList<Drawable>();
        //creates the rain
        for (int i = 0; i < 10; i++) {
            Line line = new Line(x + (i * 10), y, x + (i * 10), y + 300);
            line.setColor(Color.WHITE);
            drawables.add(line);
        }
        //draws a cloud using 5 circles in shades of gray
        Point center1 = new Point(x, y);
        Circle circle1 = new Circle(center1, 30);
        int r = 204;
        Color myColor = new Color(r, r, r);
        circle1.setColor(myColor);
        circle1.setFilled(true);
        drawables.add(circle1);
        Point center2 = new Point(x + 20, y + 20);
        Circle circle2 = new Circle(center2, 30);
        circle2.setColor(myColor);
        circle2.setFilled(true);
        drawables.add(circle2);
        Point center3 = new Point(x + 45, y - 10);
        Circle circle3 = new Circle(center3, 40);
        circle3.setColor(Color.LIGHT_GRAY);
        circle3.setFilled(true);
        drawables.add(circle3);
        Point center4 = new Point(x + 65, y + 30);
        Circle circle4 = new Circle(center4, 35);
        r = 163;
        myColor = new Color(r, r, r);
        circle4.setColor(myColor);
        circle4.setFilled(true);
        drawables.add(circle4);
        Point center5 = new Point(x + 95, y - 5);
        Circle circle5 = new Circle(center5, 40);
        circle5.setColor(myColor);
        circle5.setFilled(true);
        drawables.add(circle5);
        return drawables; //the cloud with the rain
    }

    /**
     * returns the background of the game.
     * @return a sprite - background
     */
    @Override
    public Sprite getBackground() {
        List<Drawable> drawables = new ArrayList<Drawable>();
        List<Drawable> drawables2 = new ArrayList<Drawable>();
        //shade of blue
        int r = 76;
        int g = 76;
        int b = 255;
        //drawables1 = drawCloud(90, 350);
        drawables.addAll(drawCloud(90, 350));
        drawables.addAll(drawCloud(600, 450));
        Color myColor = new Color(r, g, b);
        return new Background(myColor, drawables);
    }

    /**
     * list of blocks to remove.
     * @return a list of blocks
     */
    @Override
    public List<Block> blocks() {
        List<Block> blockList = new ArrayList<Block>();
        int count = 1;
        Color color;
        for (int j = 0; j < 5; j++) {
            for (int i = 730; i > 0; i = i - 51) {
                Point center = new Point(i, 100 + (j * 30));
                Rectangle rect = new Rectangle(center, 51, 30);
                color = chooseColorForBlock(j);
                Block block = new Block(rect, color);
                block.setHits(1);
                blockList.add(block);
                count++;
            }
        }
        return blockList;
    }

    /**
     * the function chooses color for the block.
     * @param j the number of the block's line
     * @return the color of the block
     */
    public Color chooseColorForBlock(int j) {
        switch (j) {
            case (0):
                return Color.green;
            case (1):
                return Color.MAGENTA;
            case (2):
                return Color.orange;
            case (3):
                return Color.pink;
            case (4):
                return Color.darkGray;
            default:
                return Color.BLACK;

        }
    }

    /**
     * @return number of blocks to remove.
     */
    @Override
    public int numberOfBlocksToRemove() {
        return REMOVE_BLOCKS_NUM;
    }
}