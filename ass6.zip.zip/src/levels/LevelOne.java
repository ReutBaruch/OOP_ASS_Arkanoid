package levels;

import animation.Background;
import animation.Drawable;
import gameobjects.Point;
import gameobjects.Rectangle;
import gameobjects.Block;
import gameobjects.LevelInformation;
import gameobjects.Velocity;
import gameobjects.Circle;
import gameobjects.Line;
import gameobjects.Sprite;



import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
/**
 * level one class.
 * implements LevelInformation.
 */
public class LevelOne implements LevelInformation {
    private static final int BALLS_NUM = 1;
    private static final int REMOVE_NUM = 1;
    private static final Velocity BALL_VELOCITY = new Velocity(0, -200);
    private static final int SCREEN_MIDDLE = 380;
    private static final int PADDLE_SPEED = 300;
    private static final int PADDLE_WIDTH = 150;
    private static final int FRAME_WIDTH = 800;
    private static final int FRAME_HEIGHT = 600;
    private static final int HEIGHT_BORDER = 580;


    /**
     * the number of balls in the level.
     * @return number of balls
     */
    @Override
    public int numberOfBalls() {
        return BALLS_NUM;
    }

    /**
     * a list of the balls velocity.
     * @return a list with the velocities
     */
    @Override
    public List<Velocity> initialBallVelocities() {
        List<Velocity> listVelocity = new ArrayList<Velocity>();
        listVelocity.add(BALL_VELOCITY);
        return listVelocity;
    }

    /**
     * paddle speed.
     * @return paddle speed.
     */
    @Override
    public int paddleSpeed() {
        return PADDLE_SPEED;
    }

    /**
     * the paddle width.
     * @return the paddle width.
     */
    @Override
    public int paddleWidth() {
        return PADDLE_WIDTH;
    }
    /**
     * the location of the paddle.
     * @return a point
     */
    @Override
    public Point paddlePoint() {
        Point pointForPaddle = new Point(SCREEN_MIDDLE - (PADDLE_WIDTH / 2), HEIGHT_BORDER - 20);
        return pointForPaddle;
    }

    /**
     * the level name.
     * @return a name
     */
    @Override
    public String levelName() {
        return "Direct Hit";
    }

    /**
     * returns the background of the game.
     * draws a target of 3 circle and 2 lines.
     * @return a sprite - background
     */
    @Override
    public Sprite getBackground() {
        List<Drawable> drawables = new ArrayList<Drawable>();
        Point center = new Point(SCREEN_MIDDLE, 180);
        Circle bigcircle = new Circle(center, 120);
        bigcircle.setColor(Color.BLUE);
        drawables.add(bigcircle);
        Circle middleCircle = new Circle(center, 80);
        middleCircle.setColor(Color.BLUE);
        drawables.add(middleCircle);
        Circle smallCircle = new Circle(center, 40);
        smallCircle.setColor(Color.BLUE);
        drawables.add(smallCircle);
        Line lineOne = new Line(center.getX() - 140, center.getY(), center.getX() + 140, center.getY());
        lineOne.setColor(Color.BLUE);
        drawables.add(lineOne);
        Line lineTwo = new Line(center.getX(), center.getY() + 140,
                center.getX(), center.getY() - 140);
        lineTwo.setColor(Color.BLUE);
        drawables.add(lineTwo);
        Background background = new Background(Color.BLACK, drawables);
        return background;
    }

    /**
     * list of blocks to remove.
     * @return a list of blocks
     */
    @Override
    public List<Block> blocks() {
        Point center = new Point(SCREEN_MIDDLE - 15, 165);
        Rectangle rect = new Rectangle(center, 30, 30);
        Block b = new Block(rect, Color.red);
        List<Block> blockList = new ArrayList<Block>();
        blockList.add(b);
        return blockList;
    }

    /**
     * @return number of blocks to remove.
     */
    @Override
    public int numberOfBlocksToRemove() {
        return REMOVE_NUM;
    }
}
