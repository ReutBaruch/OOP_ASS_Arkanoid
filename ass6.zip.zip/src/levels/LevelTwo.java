package levels;

import animation.Background;
import animation.Drawable;
import gameobjects.Point;
import gameobjects.Rectangle;
import gameobjects.Block;
import gameobjects.LevelInformation;
import gameobjects.Velocity;
import gameobjects.Circle;
import gameobjects.Line;
import gameobjects.Sprite;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
/**
 * level two class.
 * implements LevelInformation.
 */
public class LevelTwo implements LevelInformation {
    private Velocity ballVelocity = new Velocity(0, -5);
    private static final int BALLS_NUM = 10;
    private static final int REMOVE_BLOCKS_NUM = 15;
    private static final int SCREEN_MIDDLE = 380;
    private static final int PADDLE_SPEED = 300;
    private static final int PADDLE_WIDTH = 700;
    private static final int HEIGHT_BORDER = 580;

    /**
     * the number of balls in the level.
     * @return number of balls
     */
    @Override
    public int numberOfBalls() {
        return BALLS_NUM;
    }

    /**
     * a list of the balls velocity.
     * @return a list with the velocities
     */
    @Override
    public List<Velocity> initialBallVelocities() {
        List<Velocity> listVelocity = new ArrayList<Velocity>();
        for (int i = 0; i < (BALLS_NUM / 2); i++) { //half goes to one direction
            ballVelocity = ballVelocity.fromAngleAndSpeed((10 + (i * 10)), 200);
            listVelocity.add(ballVelocity);
        }
        for (int i = 0; i < (BALLS_NUM / 2); i++) { //half goes to another direction
            ballVelocity = ballVelocity.fromAngleAndSpeed((-50 + (i * 10)), 200);
            listVelocity.add(ballVelocity);
        }
        return listVelocity;
    }

    /**
     * paddle speed.
     * @return paddle speed.
     */
    @Override
    public int paddleSpeed() {
        return PADDLE_SPEED;
    }

    /**
     * the paddle width.
     * @return the paddle width.
     */
    @Override
    public int paddleWidth() {
        return PADDLE_WIDTH;
    }

    /**
     * the location of the paddle.
     * @return a point
     */
    @Override
    public Point paddlePoint() {
        Point pointForPaddle = new Point(50, HEIGHT_BORDER - 20);
        return pointForPaddle;
    }

    /**
     * the level name.
     * @return a name
     */
    @Override
    public String levelName() {
        return "Wide Easy";
    }

    /**
     * returns the background of the game.
     * draws a sun using 3 circles and lines
     * @return a sprite - background
     */
    @Override
    public Sprite getBackground() {
        List<Drawable> drawables = new ArrayList<Drawable>();
        Point center = new Point(150, 150);
        Circle bigcircle = new Circle(center, 60);
        //(243,247,135)
        int r = 243;
        int g = 247;
        int b = 135;
        Color myColor = new Color(r, g, b);
        for (int i = 740; i > 20; i = i - 5) {
            Line line = new Line(center.getX(), center.getY(), i, 250);
            line.setColor(myColor);
            drawables.add(line);
        }
        bigcircle.setColor(myColor);
        bigcircle.setFilled(true);
        drawables.add(bigcircle);
        Circle middleCircle = new Circle(center, 45);
        r = 251;
        g = 224;
        b = 63;
        myColor = new Color(r, g, b);
        middleCircle.setColor(myColor);
        middleCircle.setFilled(true);
        drawables.add(middleCircle);
        Circle smallCircle = new Circle(center, 30);
        //(235,242,56)
        r = 235;
        g = 242;
        b = 56;
        myColor = new Color(r, g, b);
        smallCircle.setColor(myColor);
        smallCircle.setFilled(true);
        drawables.add(smallCircle);
        return new Background(Color.WHITE, drawables);
    }

    /**
     * list of blocks to remove.
     * @return a list of blocks
     */
    @Override
    public List<Block> blocks() {
        List<Block> blockList = new ArrayList<Block>();
        int count = 1;
        for (int i = 730; i > 0; i = i - 51) {
            Point center = new Point(i, 250);
            Rectangle rect = new Rectangle(center, 51, 30);
            Block b;
            if (count < 3) {
                b = new Block(rect, Color.CYAN);
            } else if (count < 5) {
                b = new Block(rect, Color.PINK);
            } else if (count < 7) {
                b = new Block(rect, Color.BLUE);
            } else if (count < 10) {
                b = new Block(rect, Color.GREEN);
            } else if (count < 12) {
                b = new Block(rect, Color.YELLOW);
            } else if (count < 14) {
                b = new Block(rect, Color.ORANGE);
            } else {
                b = new Block(rect, Color.RED);
            }
            blockList.add(b);
            count = count + 1;
        }
        return blockList;
    }

    /**
     * @return number of blocks to remove.
     */
    @Override
    public int numberOfBlocksToRemove() {
        return REMOVE_BLOCKS_NUM;
    }
}