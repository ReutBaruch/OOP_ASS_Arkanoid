package levels;

import animation.Background;
import animation.Drawable;
import gameobjects.Point;
import gameobjects.Rectangle;
import gameobjects.Block;
import gameobjects.LevelInformation;
import gameobjects.Velocity;
import gameobjects.Circle;
import gameobjects.Sprite;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
/**
 * level three class.
 * implements LevelInformation.
 */
public class LevelThree implements LevelInformation {
    private Velocity ballVelocity = new Velocity(5, -5);
    private static final int BALLS_NUM = 2;
    private static final int REMOVE_BLOCKS_NUM = 35;
    private static final int SCREEN_MIDDLE = 380;
    private static final int PADDLE_SPEED = 300;
    private static final int PADDLE_WIDTH = 150;
    private static final int HEIGHT_BORDER = 580;

    /**
     * the number of balls in the level.
     * @return number of balls
     */
    @Override
    public int numberOfBalls() {
        return BALLS_NUM;
    }

    /**
     * a list of the balls velocity.
     * @return a list with the velocities
     */
    @Override
    public List<Velocity> initialBallVelocities() {
        List<Velocity> listVelocity = new ArrayList<Velocity>();
        ballVelocity = new Velocity(200, -200);
        listVelocity.add(ballVelocity);
        ballVelocity = new Velocity(-200, -200);
        listVelocity.add(ballVelocity);
        return listVelocity;
    }

    /**
     * paddle speed.
     * @return paddle speed.
     */
    @Override
    public int paddleSpeed() {
        return PADDLE_SPEED;
    }

    /**
     * the paddle width.
     * @return the paddle width.
     */
    @Override
    public int paddleWidth() {
        return PADDLE_WIDTH;
    }

    /**
     * the location of the paddle.
     * @return a point
     */
    @Override
    public Point paddlePoint() {
        Point pointForPaddle = new Point(SCREEN_MIDDLE - (PADDLE_WIDTH / 2), HEIGHT_BORDER - 20);
        return pointForPaddle;
    }

    /**
     * the level name.
     * @return a name
     */
    @Override
    public String levelName() {
        return "Green 3";
    }

    /**
     * returns the background of the game.
     * draws building.
     * @return a sprite - background
     */
    @Override
    public Sprite getBackground() {
        List<Drawable> drawables = new ArrayList<Drawable>();
        Point forBigBlock = new Point(50, 400);
        Rectangle bigBlock = new Rectangle(forBigBlock, 120, 200);
        bigBlock.setFilled(true);
        bigBlock.setColor(Color.BLACK);
        drawables.add(bigBlock);
        Point forMiddleBlock = new Point(90, 350);
        Rectangle middleBlock = new Rectangle(forMiddleBlock, 40, 50);
        middleBlock.setFilled(true);
        middleBlock.setColor(Color.gray);
        drawables.add(middleBlock);
        Point forLongBlock = new Point(105, 150);
        Rectangle longBlock = new Rectangle(forLongBlock, 12, 200);
        longBlock.setFilled(true);
        longBlock.setColor(Color.lightGray);
        drawables.add(longBlock);
        Point forCircle = new Point(110, 150);
        Circle big = new Circle(forCircle, 13);
        big.setFilled(true);
        big.setColor(Color.ORANGE);
        drawables.add(big);
        Circle middle = new Circle(forCircle, 10);
        middle.setFilled(true);
        middle.setColor(Color.RED);
        drawables.add(middle);
        Circle small = new Circle(forCircle, 5);
        small.setFilled(true);
        small.setColor(Color.WHITE);
        drawables.add(small);
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 60; j = j + 10) {
                for (int k = 0; k < 200; k = k + 35) {
                    Point forBlock = new Point(58 + (j * 2), 415 + (k));
                    Rectangle block = new Rectangle(forBlock, 10, 25);
                    block.setFilled(true);
                    block.setColor(Color.WHITE);
                    drawables.add(block);
                }
            }
        }
        int r = 0;
        int g = 128;
        int b = 0;
        Color myColor = new Color(r, g, b);
        return new Background(myColor, drawables);
    }

    /**
     * list of blocks to remove.
     * @return a list of blocks
     */
    @Override
    public List<Block> blocks() {
        List<Block> blockList = new ArrayList<Block>();
        for (int j = 0; j < 5; j++) {
            int w = 60 * j;
            int y = 130 + (30 * j);
            Color color;
            for (int i = 0; i < 9 - j; i++) {
                Point point = new Point((250 + w) + (i * 60), y);
                Rectangle rect = new Rectangle(point, 60, 30);
                color = chooseColorForBlock(j);
                Block block = new Block(rect, color);
                block.setHits(1);
                blockList.add(block);
            }
        }
        return blockList;
    }

    /**
     * the function chooses color for the block.
     * @param j the number of the block's line
     * @return the color of the block
     */
    public Color chooseColorForBlock(int j) {
        switch (j) {
            case (0):
                return Color.green;
            case (1):
                return Color.MAGENTA;
            case (2):
                return Color.orange;
            case (3):
                return Color.pink;
            case (4):
                return Color.darkGray;
            default:
                return Color.BLACK;

        }
    }

    /**
     * @return number of blocks to remove.
     */
    @Override
    public int numberOfBlocksToRemove() {
        return REMOVE_BLOCKS_NUM;
    }
}