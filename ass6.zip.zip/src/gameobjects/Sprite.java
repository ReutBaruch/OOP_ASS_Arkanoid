package gameobjects;

import biuoop.DrawSurface;

/**
 * gameobjects.Sprite interface.
 */
public interface Sprite {
    /**
     * draw the sprite to the screen.
     * @param d a drawn surface
     */
    void drawOn(DrawSurface d);

    /**
     * notify the sprite that time has passed.
     * @param dt the change in the velocity.
     */
    void timePassed(double dt);
}