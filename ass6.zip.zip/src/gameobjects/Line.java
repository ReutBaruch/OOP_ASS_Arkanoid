package gameobjects;

import animation.Drawable;
import biuoop.DrawSurface;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * the class creates lines using the gameobjects.Point class.
 * methods:
 * creates lines
 * calculate the length of a line.
 * checks if the lines are equal
 * checks if the lines intersect and can return the intersection point.
 * calculate the middle point of a line.
 */
public class Line implements Drawable {
    private Point start;
    private Point end;
    private Color color;
    /**
     * Construct a line given 2 points.
     *
     * @param start the start point
     * @param end   the end point
     */
    public Line(Point start, Point end) {
        this.start = start;
        this.end = end;
    }
    /**
     * creates two points.
     *
     * @param x1 the first point - x coordinate
     * @param y1 the first point - y coordinate
     * @param x2 the second point - x coordinate
     * @param y2 the second point - y coordinate
     */
    public Line(double x1, double y1, double x2, double y2) {
        this.start = new Point(x1, y1);
        this.end = new Point(x2, y2);
    }
    /**
     * calculate the length of the line.
     *
     * @return the length of the line.
     */
    public double length() {
        double length = this.start.distance(this.end);
        return length;
    }

    /**
     * sets the color.
     * @param c a color
     */
    public void setColor(Color c) {
        this.color = c;
    }

    /**
     * calculate the middle point of a line.
     * @return the middle point of the line
     */
    public Point middle() {
        double middleX = (this.start.getX() + this.end.getX()) / 2;
        double middleY = (this.start.getY() + this.end.getY()) / 2;
        Point middle = new Point(middleX, middleY);
        return middle;
    }
    /**
     * @return the start point of the line
     */
    public Point start() {
        return this.start;
    }
    /**
     * @return the end point of the line
     */
    public Point end() {
        return this.end;
    }
    /**
     * checks if the points are equal.
     * @param other another line
     * @return true if the points are equal, false otherwise
     */
    public boolean equals(Line other) {
        //first scenario:  start = start, end = end
        if (this.start.getX() == other.start.getX()) {
            if (this.start.getY() == other.start.getY()) {
                if (this.end.getX() == other.end.getX()) {
                    if (this.end.getY() == other.end.getY()) {
                        return true;
                    }
                }
            }
            //second scenario:  start = end, end = start
        } else if (this.start.getX() == other.end.getX()) {
            if (this.start.getY() == other.end.getY()) {
                if (this.end.getX() == other.start.getX()) {
                    if (this.end.getY() == other.start.getY()) {
                        return true;
                    }
                }
            }
        }
        return false; //the lines are not equals
    }
    /**
     * calculate the intersection point between two line segments.
     *
     * @param other another line
     * @return the intersection point if they intersect, null otherwise
     */
    public Point calculateIntersecting(Line other) {
        double start1X = this.start.getX();
        double end1X = this.end.getX();
        double start1Y = this.start.getY();
        double end1Y = this.end.getY();
        double start2X = other.start.getX();
        double end2X = other.end.getX();
        double start2Y = other.start.getY();
        double end2Y = other.end.getY();
        //we will solve the 2 equations of: Ax+By=c
        double a1 = end1Y - start1Y; //parameters for the first equation end with 1
        double b1 = start1X - end1X;
        double c1 = (a1 * start1X) + (b1 * start1Y); //C = Ax + By
        double a2 = end2Y - start2Y; //parameters for the first equation end with 2
        double b2 = start2X - end2X;
        double c2 = (a2 * start2X) + (b2 * start2Y); //C = Ax + By
        double denominator = (a1 * b2) - (a2 * b1); //the denominator is: (A1 * B1) - (A2 * B2)
        if ((b1 == 0) ||  (b2 == 0)) { //separate check for vertical lines
            return this.intersectVertical(other);
        }
        if ((a1 == 0) || (a2 == 0)) { //separate check for horizontal lines
            return this.intersectionHorizontal(other);
        }
        if (denominator <= 0) { // they do not intersect
            return null;
        }
        double intersectX = (b2 * c1 - b1 * c2) / denominator; //the x coordinate of the intersection point
        double intersectY = (a1 * c2 - a2 * c1) / denominator; //the y coordinate of the intersection point
        Point intersectP = new Point(intersectX, intersectY); //creating the intersection point
        //because its line segment need to check if the intersection point is on the line
        double rangeX0 = (intersectX - start1X) / (end1X - start1X); //range for the x coordinate of the first line
        double rangeY0 = (intersectY - start1Y) / (end1Y - start1Y); //range for the y coordinate of the first line
        double rangeX1 = (intersectX - start2X) / (end2X - start2X); //range for the x coordinate of the second line
        double rangeY1 = (intersectY - start2Y) / (end2Y - start2Y); //range for the y coordinate of the second line
        if (((rangeX0 >= 0 && rangeX0 <= 1) || (rangeY0 >= 0 && rangeY0 <= 1)) //if its in the range of the two line
                && ((rangeX1 >= 0 && rangeX1 <= 1) || (rangeY1 >= 0 && rangeY1 <= 1))) {
            return intersectP;
        } else {
            return null; //the point is outside the range
        }
    } //ent of calculateIntersecting

    /**
     * the cunction check if the intersection point is on the line segment.
     * @param intersect intersecton point of two lines segment
     * @return true if the point is on the line, false otherwise
     */
    public boolean isRange(Point intersect) {
        //first case: the line's startX < endX
        if ((intersect.getX() <= this.start().getX()) && (intersect.getX() >= this.end().getX())) {
            //first case: the line's startY < endY
            if ((intersect.getY() >= this.start().getY()) && (intersect.getY() <= this.end().getY())) {
                return true;
                //second case: the line's startY > endY
            } else if ((intersect.getY() <= this.start().getY()) && (intersect.getY() >= this.end().getY())) {
                return true;
            }
            //second case: the line's startX > endX
        } else if ((intersect.getX() >= this.start().getX()) && (intersect.getX() <= this.end().getX())) {
            //first case: the line's startY < endY
            if ((intersect.getY() >= this.start().getY()) && (intersect.getY() <= this.end().getY())) {
                return true;
                //second case: the line's startY > endY
            } else if ((intersect.getY() <= this.start().getY()) && (intersect.getY() >= this.end().getY())) {
                return true;
            }
        }
        return false; //the point is not on the lines segment
    }
    /**
     * tells if the lines intersect or not.
     *
     * @param other another line
     * @return true if they intersect, false otherwise
     */
    public boolean isIntersecting(Line other) {
        Point returnedValue;
        /*returnedValue = intersectVertical(other);
        if (returnedValue == null) {*/
        returnedValue = calculateIntersecting(other);
        //}
        return (returnedValue == null);
    }
    /**
     * returns the intersection point of two line segment.
     *
     * @param other another line
     * @return the intersection point if they intersect, false otherwise
     */
    public Point intersectionWith(Line other) {
        Point returnedValue = calculateIntersecting(other);
        if (returnedValue == null) {
            return null; //they do not intersect
        } else {
            return returnedValue; //the intersection point
        }
    }

    /**
     * the function check if horizontal lines segments intersect.
     * @param line another line
     * @return the intersection point if they intersect, null otherwise
     */
    public Point intersectionHorizontal(Line line) {
        double incline;
        double intersectX;
        Point range;
        //first case: the first line is horizontal
        if (this.start.getY() - this.end.getY() == 0) {
            //calculate the second line's incline
            incline = ((line.start.getY() - line.end.getY()) / (line.start.getX() - line.end.getX()));
            //finding the x coordinate with the equation: (y - Y)m + X
            intersectX = ((this.start.getY() - line.start.getY()) / incline) + line.start.getX();
            range = new Point(intersectX, this.start.getY());
            //checks if the intersection point is on the lines segments
            if ((this.isRange(range)) && (line.isRange(range))) {
                return range; //they intersect
            }
            return null;
            //second case: the second line is horizontal
        } else if (line.start.getY() - line.end.getY() == 0) {
            //calculate the first line's incline
            incline = ((this.start.getY() - this.end.getY()) / (this.start.getX() - this.end.getX()));
            //finding the x coordinate with the equation: (y - Y)m + X
            intersectX = ((line.start.getY() - this.start.getY()) / incline) + this.start.getX();
            range = new Point(intersectX, line.start.getY());
            //checks if the intersection point is on the lines segments
            if ((this.isRange(range)) && (line.isRange(range))) {
                return range; //they intersect
            }
            return null;
        }
        return null; //they do not intersect
    }

    /**
     * the function checks if vertical lines intersect.
     * @param line another line
     * @return the intersection point
     */
    public Point intersectVertical(Line line) {
        double incline;
        double intersectY;
        Point range;
        //first case: the first line is vertical
        if ((this.start.getX() - this.end.getX()) == 0) {
            //calculate the second line's incline
            incline = ((line.start.getY() - line.end.getY()) / (line.start.getX() - line.end.getX()));
            //finding the y coordinate with the equation: m(x - X) + Y
            intersectY = incline * (this.start.getX() - line.start.getX()) + line.start.getY();
            range = new Point(this.start.getX(), intersectY);
            //checks if the intersection point is on the lines segments
            if ((this.isRange(range)) && (line.isRange(range))) {
                return range;
            }
            return null;
            //second case: the second line is vertical
        } else if ((line.start.getX() - line.end.getX()) == 0) {
            //calculate the first line's incline
            incline = ((this.start.getY() - this.end.getY()) / (this.start.getX() - this.end.getX()));
            //finding the y coordinate with the equation: m(x - X) + Y
            intersectY = incline * (line.start.getX() - this.start.getX()) + this.start.getY();
            range = new Point(line.start().getX(), intersectY);
            //checks if the intersection point is on the lines segments
            if ((this.isRange(range)) && (line.isRange(range))) {
                return range;
            }
            return null;
        }
        return null; //they do not intersect
    }

    /**
     * the function checks what is the closest intersection point.
     * between a line and a rectangle.
     * @param rect a rectangle
     * @return the closest intersection point
     */
    public Point closestIntersectionToStartOfLine(Rectangle rect) {
        if (rect == null) {
            return null; //nothing was received
        }
        //sent to a func that finds intersection points
        List<Point> listPointFromRect = rect.intersectionPoints(this);
        if (listPointFromRect == null) {
            return null; //there were no intersections pints
        }
        //sent to a func that finds the closest one
        return minDistancePoint(listPointFromRect); //returns the closest intersection point

    }

    /**
     * the functions finds the closest intersection point to the start of a line.
     * @param list a list of intersection points
     * @return the closest intersection point to the start of a line
     */
    public Point minDistancePoint(List<Point> list) {
        if (list.size() == 0) {
            return null; //no points
        }
        List distances = new ArrayList();
        for (int i = 0; i < list.size(); i++) {
            //calculate the distance between the start point of a line and another point
            distances.add(this.start.distance(list.get(i)));
        }
        double min = (double) distances.get(0);
        Point returnPoint = (Point) list.get(0);
        for (int i = 1; i < distances.size(); i++) {
            //finds the minimal distance
            if (min > (double) distances.get(i)) {
                min = (double) distances.get(i);
                returnPoint = (Point) list.get(i);
            }
        }
        return returnPoint; //returns the closest point
    }
    /**
     * draws the shape to the screen.
     * @param d a draw surface
     */
    @Override
    public void draw(DrawSurface d) {
        d.setColor(color);
        d.drawLine((int) this.start().getX(), (int) this.start.getY(), (int) this.end.getX(), (int) this.end.getY());
    }
}