package gameobjects;

import biuoop.DrawSurface;
import gameflow.GameLevel;

import java.awt.Color;
import java.awt.Image;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * the class implements the gameobjects.Collidable interface.
 * the class creates blocks.
 */
public class Block implements Collidable, Sprite, HitNotifier {
    private int xCoordinate;
    private int yCoordinate;
    private int height;
    private int width;
    private Rectangle rect;
    private Color color;
    private int hits;
    private List<HitListener> hitListeners;
    private Map<Integer, Color> fillingColor;
    private Map<Integer, Image> fillingImage;
    private Color stroke;

    /**
     * constructor.
     * @param upperLeft point
     * @param width of the bloc
     * @param height of the bloc
     * @param color of the bloc
     * @param hits left till the block disappears
     */
    public Block(Point upperLeft, double width, double height, Color color, int hits) {
        this.rect = new Rectangle(upperLeft, width, height);
        this.color = color;
        this.hits = hits;
        this.hitListeners = new ArrayList<HitListener>();
        this.fillingColor = new HashMap<Integer, Color>();
        this.fillingImage = new HashMap<Integer, Image>();
    }

    /**
     * Construct a block.
     * @param rect a rectangle
     * @param color the color of the block
     */
    public Block(Rectangle rect, Color color) {
        this.rect = rect;
        this.color = color;
        hitListeners = new ArrayList<HitListener>();
        this.fillingColor = new HashMap<Integer, Color>();
        this.fillingImage = new HashMap<Integer, Image>();
    }

    /**
     * sets the number of hits.
     * @param otherHits number of hits.
     */
    public void setHits(int otherHits) {
        this.hits = otherHits;
    }

    /**
     * setter.
     * @param heightTemp the block height
     */
    public void setHeight(int heightTemp) {
        this.height = heightTemp;
    }

    /**
     * setter.
     * @param w the block width
     */
    public void setWidth(int w) {
        this.width = w;
    }

    /**
     * setter.
     * @param c the block color
     */
    public void setColor(Color c) {
        this.color = c;
    }


    /**
     * set the map of color filling block.
     * @param filling the map from hits left to a color
     */
    public void setFillingColor(Map<Integer, Color> filling) {
        this.fillingColor = filling;
    }

    /**
     * set the map of image filling block.
     * @param filling the map from hits left to an image
     */
    public void setFillingImage(Map<Integer, Image> filling) {
        this.fillingImage = filling;
    }

    /**
     * sets a stroke.
     * @param c a color
     */
    public void setStroke(Color c) {
        this.stroke = c;
    }


    /**
     * get the number of possible hits before destruction.
     * @return number of hits
     */
    public int getHits() {
        return this.hits;
    }

    /**
     * accessor to receive the rectangle.
     * @return the shape of the block
     */
    public Rectangle getCollisionRectangle() {
        if (rect == null) {
            this.rect =  new Rectangle(new Point(this.xCoordinate, this.yCoordinate), this.width, this.height);
        }
        return this.rect;
    }

    /**
     * adds the block to the gameflow environment.
     * @param g the gameflow environment
     */
    public void addToGame(GameLevel g) {
        g.addSprite(this);
        g.addCollidable(this);
    }

    /**
     * removes the block from the game.
     * @param gameLevel the game it should be removed from
     */
    public void removeFromGame(GameLevel gameLevel) {
        gameLevel.removeCollidable(this);
        gameLevel.removeSprite(this);
    }
    /**
     * the function change the velocity of an object according to the collision point.
     * @param collisionPoint the collision point
     * @param currentVelocity the current velocity of an object.
     * @param hitter the ball that hit
     * @return the new velocity - after the hit.
     */
    public Velocity hit(Ball hitter, Point collisionPoint, Velocity currentVelocity) {
        double dx = currentVelocity.getDx();
        double dy = currentVelocity.getDy();
        Velocity velocityTemp;
        //the collision point is on the left line of the rectangle
        if (rect.getLineY().isRange(collisionPoint)) {
            dx = (-dx);
            //the collision point is on the right line of the rectangle
        } else if (rect.getLineParallelY().isRange(collisionPoint)) {
            dx = (-dx);
        }
        //the collision point is on the lower line of the rectangle
        if ((rect.getLineParallelX().isRange(collisionPoint))) {
            dy = (-dy);
            //the collision point is on the upper line of the rectangle
        } else if (rect.getLineX().isRange(collisionPoint)) {
            dy = (-dy);
        }
        velocityTemp = new Velocity(dx, dy);
        //change the number of hits
        if (hits != 1) {
            setHits(getHits() - 1);
        } else {
            setHits(0);
        }
        this.notifyHit(hitter);
        return velocityTemp; //returns the new velocity
    }

    /**
     * the function draws the blocks on the screen.
     * @param d a drawn surface
     */
    public void drawOn(DrawSurface d) {
        int x = (int) rect.getUpperLeft().getX();
        int y = (int) rect.getUpperLeft().getY();
        int w = (int) rect.getWidth();
        int h = (int) rect.getHeight();
        if (fillingColor.containsKey(hits)) {
            d.setColor(fillingColor.get(hits));
            d.fillRectangle(x, y, w, h);
        } else if (fillingImage.containsKey(hits)) {
            d.drawImage(x, y, fillingImage.get(hits));
        } else if (fillingColor.containsKey(0)) {
            d.setColor(fillingColor.get(0));
            d.fillRectangle(x, y, w, h);
        } else if (fillingImage.containsKey(0)) {
            d.drawImage(x, y, fillingImage.get(0));
        } else if (this.color != null) {
            d.setColor(this.color);
            d.fillRectangle(x, y, w, h);
        }
        if (this.stroke != null) {
            d.setColor(this.stroke);
            d.drawRectangle(x, y, w, h);
        }
    }

    /**
     * tells the block time passed.
     * @param dt the change in the velocity.
     */
    public void timePassed(double dt) {
        return;
    }

    @Override
    public void addHitListener(HitListener hl) {
        hitListeners.add(hl);
    }

    @Override
    public void removeHitListener(HitListener hl) {
        hitListeners.remove(hl);
    }
    /**
     * when a hit occurs.
     * @param hitter the ball that hit
     */
    private void notifyHit(Ball hitter) {
        // Make a copy of the hitListeners before iterating over them.
        List<HitListener> listeners = new ArrayList<HitListener>(this.hitListeners);
        // Notify all listeners about a hit event:
        for (HitListener hl : listeners) {
            hl.hitEvent(this, hitter);
        }
    }
}

