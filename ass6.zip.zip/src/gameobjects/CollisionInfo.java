package gameobjects;

/**
 * the class gives information about the collidables and the collision point.
 */
public class CollisionInfo {
    private Collidable coll;
    private Point collisionPoint;

    /**
     * accessor.
     * @param collisionPoint teh collision point
     * @param coll a collidable
     */
    public CollisionInfo(Point collisionPoint, Collidable coll) {
        this.coll = coll;
        this.collisionPoint = collisionPoint;
    }
    /**
     * accessor.
     * @return the point at which the collision occurs.
     */
    public Point collisionPoint() {
        return this.collisionPoint;
    }
    /**
     * accessor.
     * @return the collidable object involved in the collision.
     */
    public Collidable collisionObject() {
        return this.coll;
    }
}
