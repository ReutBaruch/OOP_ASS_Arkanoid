package gameobjects;

import java.util.List;

/**
 * specifies the information required to fully describe a level.
 */
public interface LevelInformation {
    /**
     * number of balls in the level.
     * @return number of balls
     */
    int numberOfBalls();
    /**
     * The initial velocity of each ball.
     * @return The initial velocity of each ball
     */
    List<Velocity> initialBallVelocities();

    /**
     * the paddle speed.
     * @return the speed
     */
    int paddleSpeed();

    /**
     * the paddle width.
     * @return the width
     */
    int paddleWidth();
    /**
     * the level name will be displayed at the top of the screen.
     * @return the level name
     */
    String levelName();

    /**
     * the level background.
     * @return the background
     */
    Sprite getBackground();

    /**
     * The Blocks that make up this level, each block contains
     * its size, color and location.
     * @return The Blocks that make up this level
     */
    List<Block> blocks();

    /**
     * Number of blocks that should be removed.
     * before the level is considered to be "cleared".
     * This number should be <= blocks.size();
     * @return Number of blocks that should be removed
     */
    int numberOfBlocksToRemove();

    /**
     * the paddle point.
     * @return the paddle point.
     */
    Point paddlePoint();
}