package gameobjects;

import animation.Drawable;
import biuoop.DrawSurface;

import java.awt.Color;

/**
 * implements Drawables.
 * responsible of drawing a circle to the screen
 */
public class Circle implements Drawable {
    private Point center;
    private int radius;
    private Color color;
    private boolean isFilled;

    /**
     *constructor.
     * @param center the center
     * @param radius the radius
     */
    public Circle(Point center, int radius) {
        this.center = center;
        this.radius = radius;
    }

    /**
     * sets the color.
     * @param c the wanted color
     */
    public void setColor(Color c) {
        this.color = c;
    }

    /**
     * if it is filled.
     * @param value true or false
     */
    public void setFilled(boolean value) {
        this.isFilled = value;
    }

    /**
     * draws the shape to the screen.
     * @param d a draw surface
     */
    @Override
    public void draw(DrawSurface d) {
        d.setColor(color);
        if (isFilled) {
            d.fillCircle((int) center.getX(), (int) center.getY(), radius);
        } else {
            d.drawCircle((int) center.getX(), (int) center.getY(), radius);
        }
    }
}
