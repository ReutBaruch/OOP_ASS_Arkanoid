package animation;

import biuoop.DrawSurface;
import biuoop.Sleeper;
import gameobjects.SpriteCollection;

import java.awt.Color;

/**
 * The animation.CountdownAnimation will display the given gameScreen.
 * for numOfSeconds seconds, and on top of them it will show
 * a countdown from countFrom back to 1, where each number will
 * appear on the screen for (numOfSeconds / countFrom) secods, before
 * it is replaced with the next one.import biuoop.DrawSurface;
 */
public class CountdownAnimation implements Animation {
    private double numOfSeconds;
    private int countFrom;
    private SpriteCollection gameScreen;
    private int tempCount;
    private static final int SCREEN_MIDDLE = 370;

    /**
     * constructor.
     * @param numOfSeconds how many seconds to wait
     * @param countFrom number to start from
     * @param gameScreen a game screen
     */
    public CountdownAnimation(double numOfSeconds, int countFrom, SpriteCollection gameScreen) {
        this.numOfSeconds = numOfSeconds;
        this.countFrom = countFrom;
        this.gameScreen = gameScreen;
        this.tempCount = countFrom;
    }

    /**
     * runs each frame of the game and takes care of the game logic.
     * @param d a draw surface.
     * @param dt the change in the velocity.
     */
    public void doOneFrame(DrawSurface d, double dt) {
        int millisecondsPerFrame = 1000 / (int) numOfSeconds;
        ;
        gameScreen.drawAllOn(d);
        d.setColor(Color.MAGENTA);
        if (tempCount != 0) { //as long we didn't reach 0
            d.drawText(SCREEN_MIDDLE, d.getHeight() / 2, String.valueOf(tempCount), 40);
        }
        if (tempCount != countFrom) { //time to wait between each number
            long startTime = System.currentTimeMillis(); // timing
            long usedTime = System.currentTimeMillis() - startTime;
            long milliSecondLeftToSleep = millisecondsPerFrame - usedTime;
            if (milliSecondLeftToSleep > 0) {
                Sleeper sleeper = new Sleeper();
                sleeper.sleepFor(milliSecondLeftToSleep);
            }
        }
        shouldStop(); //stop condition
        tempCount = tempCount - 1;
    }
    /**
     * stop condition.
     * @return true or false
     */
    public boolean shouldStop() {
        if (this.tempCount == -1) {
            return true;
        }
        return false;
    }
}