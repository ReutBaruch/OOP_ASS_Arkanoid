package animation;

import biuoop.DrawSurface;
import biuoop.KeyboardSensor;

import java.awt.Color;

/**
 * implements Animation.
 * presents a pause screen when pressing P.
 */
public class PauseScreen implements Animation {
    private KeyboardSensor keyboard;
    private boolean stop;
    /**
     * constructor.
     * @param k a KeyboardSensor
     */
    public PauseScreen(KeyboardSensor k) {
        this.keyboard = k;
        this.stop = false;
    }
    /**
     * runs each frame of the game and takes care of the game logic.
     * @param d a draw surface.
     * @param dt the change in the velocity.
     */
    public void doOneFrame(DrawSurface d, double dt) {
        d.setColor(Color.pink);
        d.fillRectangle(0, 0, 900, 900);
        d.setColor(Color.gray);
        d.drawText(10, d.getHeight() / 2, "paused -- press space to continue", 32);
    }
    /**
     * stop condition.
     * @return true or false
     */
    public boolean shouldStop() {
        return this.stop;
    }
}