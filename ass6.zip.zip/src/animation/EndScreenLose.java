package animation;

import biuoop.DrawSurface;
import biuoop.KeyboardSensor;
import indicator.Counter;

import java.awt.Color;

/**
 * implements Animation.
 * presents a end screen when loosing.
 */
public class EndScreenLose implements Animation {
    private KeyboardSensor keyboard;
    private boolean stop;
    private Counter score;

    /**
     * constructor.
     * @param k a KeyboardSensor
     * @param score counter for score
     */
    public EndScreenLose(KeyboardSensor k, Counter score) {
        this.keyboard = k;
        this.stop = false;
        this.score = score;
    }
    /**
     * runs each frame of the game and takes care of the game logic.
     * @param d a draw surface.
     * @param dt the change in the velocity.
     */
    public void doOneFrame(DrawSurface d, double dt) {
        d.setColor(Color.pink);
        d.fillRectangle(0, 0, 900, 900);
        d.setColor(Color.gray);
        d.drawText(150, d.getHeight() / 2, "Game OVER!", 32);
        d.drawText(150, (d.getHeight() / 2) + 35, "your score is " + score.getValue(), 32);
    }
    /**
     * stop condition.
     * @return true or false
     */
    public boolean shouldStop() {
        return this.stop;
    }
}