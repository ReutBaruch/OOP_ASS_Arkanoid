package animation;

/**
 * creates a selection for the menu.
 * @param <T> can receive any object
 */
public class Selection<T> {
    private String key;
    private String message;
    private T returnVal;
    private Menu subMenu;
    private Boolean isSub;

    /**
     * constructor.
     * @param key stopping key
     * @param message a message to show on the screen
     * @param returnVal a value it returns
     */
    public Selection(String key, String message, T returnVal) {
        this.key = key;
        this.message = message;
        this.returnVal = returnVal;
        this.subMenu = null;
        this.isSub = false;
        if (key.equals("s")) {
            this.subMenu = (Menu) returnVal;
            isSub = true;
        }
    }

    /**
     * getter.
     * @return the stopping key
     */
    public String getKey() {
        return key;
    }

    /**
     * if its a sub menu.
     * @return yes or no
     */
    public boolean getIsSub() {
        return this.isSub;
    }

    /**
     * returns the sub menu.
     * @return the sub menu
     */
    public Menu getSubMenu() {
        return subMenu;
    }

    /**
     * getter.
     * @return the message
     */
    public String getMessage() {
        return message;
    }

    /**
     * getter.
     * @return the selected object
     */
    public T getReturnVal() {
        return returnVal;
    }
}
