package animation;

import biuoop.DrawSurface;
import biuoop.KeyboardSensor;

/**
 * the class is responsible for all class that uses a key to stop there activity.
 */
public class KeyPressStoppableAnimation implements Animation {
    private KeyboardSensor sensor;
    private String key;
    private Animation animation;
    private boolean stop;
    private boolean isAlreadyPressed;

    /**
     * constructor.
     * @param sensor a KeyboardSensor
     * @param key stoping key
     * @param animation a running animation
     */
    public KeyPressStoppableAnimation(KeyboardSensor sensor, String key, Animation animation) {
        this.sensor = sensor;
        this.key = key;
        this.animation = animation;
        this.stop = false;
        this.isAlreadyPressed = true;
    }

    @Override
    /**
     * runs each frame of the game and takes care of the game logic.
     * @param d a draw surface.
     * @param dt the change in the velocity.
     */
    public void doOneFrame(DrawSurface d, double dt) {
        this.animation.doOneFrame(d, dt);
        if (this.sensor.isPressed(this.key)) {
            if (!isAlreadyPressed) {
                this.stop = true;
            } else {
                this.isAlreadyPressed = false;
            }
        }
    }

    @Override
    /**
     * stop condition.
     * @return true or false
     */
    public boolean shouldStop() {
        return this.stop;
    }
}
