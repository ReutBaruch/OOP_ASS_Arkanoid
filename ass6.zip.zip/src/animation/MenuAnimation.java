package animation;

import biuoop.DrawSurface;
import biuoop.KeyboardSensor;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * a menu animation class.
 * implements menu
 * @param <T> can receive any object
 */
public class MenuAnimation<T> implements Menu<T> {
    private List<Selection> selections;
    private T status;
    private KeyboardSensor sensor;
    private Boolean stop;
    private AnimationRunner runner;
    private List<T> menuReturnValues;
    private List<String> menuItemNames;
    private List<String> menuItemKeys;
    private List<Boolean> isSubMenu;
    private List<Menu<T>> subMenus;

    /**
     * constructor.
     * @param sensor a KeyboardSensor
     * @param animationRunner an animation runner to run the menu
     */
    public MenuAnimation(KeyboardSensor sensor, AnimationRunner animationRunner) {
        this.selections = new ArrayList<>();
        this.status = null;
        this.sensor = sensor;
        this.stop = false;
        this.runner = animationRunner;
        menuReturnValues = new ArrayList<>();
        menuItemNames = new ArrayList<>();
        menuItemKeys = new ArrayList<>();
        isSubMenu = new ArrayList<>();
        subMenus = new ArrayList<>();
    }

    @Override
    public void addSelection(String key, String message, T returnVal) {
        this.selections.add(new Selection(key, message, returnVal));
    }

    @Override
    public T getStatus() {
        return this.status;
    }

    @Override
    public void setStop(Boolean val) {
        this.stop = val;
    }

    @Override
    public void doOneFrame(DrawSurface d, double dt) {
        d.setColor(Color.pink);
        d.fillRectangle(0, 0, 900, 900);
        d.setColor(Color.GRAY);
        for (int i = 0; i < selections.size(); i++) {
            d.drawText(250, 200 + (i * 50), selections.get(i).getMessage(), 32);
        }
        for (int i = 0; i < selections.size(); i++) {
            if (sensor.isPressed(selections.get(i).getKey())) { //if its not a sub menu
                if (!selections.get(i).getIsSub()) {
                    this.status = (T) this.selections.get(i).getReturnVal();
                    this.stop = true;
                    break;
                } else { //if its a sub menu
                    Menu<T> sub = (Menu) this.selections.get(i).getSubMenu();
                    this.runner.run(sub);
                    this.status = sub.getStatus();
                    this.selections.get(i).getSubMenu().doOneFrame(d, dt); //so the main menu won't pop up
                    this.selections.get(i).getSubMenu().setStop(false);
                    this.stop = true;
                    return;
                }
            }
        }
    }

    @Override
    public boolean shouldStop() {
        return this.stop;
    }
    @Override
    public void addSubMenu(String key, String message, Menu<T> subMenu) {
        this.selections.add(new Selection(key, message, subMenu));
        this.menuItemKeys.add(key);
        this.menuItemNames.add(message);
        this.menuReturnValues.add(null);
        this.isSubMenu.add(true);
        this.subMenus.add(subMenu);
    }
}