package animation;

/**
 * an interface for creating a menu.
 * @param <T> can receive any object
 */
public interface Menu<T> extends Animation {
    /**
     * adds a selection to the menu.
     * @param key stopping key
     * @param message a message to show on the screen
     * @param returnVal a value it returns
     */
    void addSelection(String key, String message, T returnVal);

    /**
     * return the status of the selection.
     * @return the status of the selection
     */
    T getStatus();

    /**
     * sets if the animation should stop.
     * @param val yes or no
     */
    void setStop(Boolean val);

    /**
     * adds a sub menu to the main menu.
     * @param key the sub menu key
     * @param message a message
     * @param subMenu the sub menu
     */
    void addSubMenu(String key, String message, Menu<T> subMenu);
}
