package animation;

import gameobjects.Sprite;
import biuoop.DrawSurface;
import java.awt.Color;
import java.util.List;

/**
 * implements the sprite interface.
 * responsible of the backgrounds of each level.
 */
public class Background implements Sprite {
    private Color color;
    private List<Drawable> objectsList;
    private static final int FRAME_WIDTH = 800;
    private static final int FRAME_HEIGHT = 600;
    private static final int INFO_LINE = 30;

    /**
     * constructor.
     * @param color a background color
     * @param objectsList objects to draw on the background.
     */
    public Background(Color color, List<Drawable> objectsList) {
        this.color = color;
        this.objectsList = objectsList;
    }

    /**
     * draws the objects on the surface.
     * @param d a drawn surface
     */
    @Override
    public void drawOn(DrawSurface d) {
        d.setColor(color);
        d.fillRectangle(0, INFO_LINE, FRAME_WIDTH, FRAME_HEIGHT);
        for (int i = 0; i < objectsList.size(); i++) {
            objectsList.get(i).draw(d);
        }
    }

    /**
     * not needed.
     * @param dt  the change in the velocity
     */
    @Override
    public void timePassed(double dt) {
    }
}
