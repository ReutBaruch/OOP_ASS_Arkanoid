package animation;

import biuoop.DrawSurface;

/**
 * shapes that can be drawn to screen.
 */
public interface Drawable {
    /**
     * draws the shape to the screen.
     * @param d a draw surface
     */
    void draw(DrawSurface d);
}
