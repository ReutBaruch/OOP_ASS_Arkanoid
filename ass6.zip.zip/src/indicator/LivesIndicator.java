package indicator;

import biuoop.DrawSurface;
import gameflow.GameLevel;
import gameobjects.Sprite;

import java.awt.Color;

/**
 * keep track of lives.
 */
public class LivesIndicator implements Sprite {
    private Counter lives;

    /**
     * constructor.
     * @param gameLives how many lives to start with.
     */
    public LivesIndicator(Counter gameLives) {
        this.lives = gameLives;
    }
    /**
     * draws the number of lives left on the screen.
     * @param d a drawn surface
     */
    @Override
    public void drawOn(DrawSurface d) {
        int value = lives.getValue();
        d.setColor(Color.BLACK);
        d.drawText(20, 25, "lives:" + String.valueOf(value), 20);
    }

    /**
     * not needed.
     * @param dt the change in the velocity.
     */
    public void timePassed(double dt) {
    }
    /**
     * adds the indicator to the game.
     * @param g a game
     */
    public void addToGame(GameLevel g) {
        g.addSprite(this);
    }
}
