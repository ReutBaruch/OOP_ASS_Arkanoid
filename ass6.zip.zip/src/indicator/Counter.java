package indicator;

/**
 * a counter.
 */
public class Counter {
    private int count = 0;
    /**
     * add number to current count.
     * @param number a number to add
     */
    public void increase(int number) {
        count = count + number;
    }
    /**
     * subtract number from current count.
     * @param number a number to decrease
     */
    public void decrease(int number) {
        count = count - number;
    }
    /**
     * get current count.
     * @return the current count.
     */
    public int getValue() {
        return this.count;
    }

    /**
     * set the counter value.
     * @param num a value
     */
    public void setCount(int num) {
        this.count = num;
    }
}